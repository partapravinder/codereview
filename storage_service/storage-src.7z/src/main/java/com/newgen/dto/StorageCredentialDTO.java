package com.newgen.dto;

import org.hibernate.validator.constraints.NotBlank;

public class StorageCredentialDTO {

	@NotBlank(message = "Name must not be blank!")
	private String name;
	
	private String storageProtocol = "http";

	@NotBlank(message = "Account name must not be blank!")
	private String accountName;

	@NotBlank(message = "Account key must not be blank!")
	private String accountKey;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}

	/**
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	/**
	 * @return the accountKey
	 */
	public String getAccountKey() {
		return accountKey;
	}

	/**
	 * @param accountKey the accountKey to set
	 */
	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}

	/**
	 * @return the storageProtocol
	 */
	public String getStorageProtocol() {
		return storageProtocol;
	}

	/**
	 * @param storageProtocol the storageProtocol to set
	 */
	public void setStorageProtocol(String storageProtocol) {
		this.storageProtocol = storageProtocol;
	}
	
	

}
