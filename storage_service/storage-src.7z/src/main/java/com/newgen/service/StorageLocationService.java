package com.newgen.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.newgen.controller.ExceptionThrower;
import com.newgen.dao.StorageLocationDao;
import com.newgen.exception.CustomException;
import com.newgen.model.StorageLocation;

@Service
public class StorageLocationService extends ExceptionThrower {

	private static final Logger logger = LoggerFactory.getLogger(StorageLocationService.class);

	@Autowired
	StorageLocationDao storageLocationDao;
	
	public StorageLocation insert(StorageLocation storageLocation) {
		logger.debug("Creating Storage location: " + storageLocation.toString());
		return storageLocationDao.insert(storageLocation);
	}

	public StorageLocation findById(String id) {
		logger.debug("Finding Storage location by id: " + id);
		return storageLocationDao.findById(id);
	}

	public void delete(String id, String version) throws CustomException {
		logger.debug("Deleting Storage location by id: " + id +" and version: " + version);
		if (version == null || version.isEmpty()) {
			if (storageLocationDao.findAndRemoveById(id) == null) {
				throwStorageLocationNotFoundException();
			}
		} else {
			if (storageLocationDao.findAndRemoveByIdAndVersion(id, version) == null) {
				StorageLocation storageLocation = storageLocationDao.findById(id);
				if (storageLocation == null) {
					throwStorageLocationNotFoundException();
				} else {
					if (!Long.toString(storageLocation.getVersion()).equalsIgnoreCase(version)) {
						throwVersionConflictException();
					} else {
						throwUnknownErrorException();
					}
				}
			}
		}
	}
}
