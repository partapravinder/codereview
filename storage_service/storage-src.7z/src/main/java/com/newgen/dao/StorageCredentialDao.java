package com.newgen.dao;

import java.util.List;
import java.util.Map;

import com.newgen.model.StorageCredentials;

public interface StorageCredentialDao {

	StorageCredentials insert(StorageCredentials storageCredentials);

	StorageCredentials findById(String id);

	StorageCredentials findAndRemoveById(String id);

	StorageCredentials findAndRemoveByIdAndVersion(String id, String version);

	StorageCredentials findAndModify(String id, Map<String, String> updateParams, Long version);

	List<StorageCredentials> findAll();

}
