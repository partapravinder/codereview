package com.newgen.dao;

import com.newgen.model.StorageLocation;

public interface StorageLocationDao {

	StorageLocation insert(StorageLocation storageLocation);

	StorageLocation findById(String id);

	StorageLocation findAndRemoveById(String id);

	StorageLocation findAndRemoveByIdAndVersion(String id, String version);

}
