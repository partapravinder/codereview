package com.newgen.dao;

import java.util.List;

import com.newgen.model.StorageProcess;
import com.newgen.model.StorageProcess.Status;

public interface StorageProcessDao {

	StorageProcess insert(StorageProcess storageProcess);

	StorageProcess findById(String id);

	StorageProcess updateStatus(String id,Status status, String storageLocationId);

	StorageProcess findAndRemoveById(String id);

	List<StorageProcess> findAllAcknowldegedAndFailed();

	List<StorageProcess> findAllCompletedForDays(int days);

}
