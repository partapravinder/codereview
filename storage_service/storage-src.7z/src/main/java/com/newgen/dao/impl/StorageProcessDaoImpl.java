package com.newgen.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mongodb.DBRef;
import com.newgen.dao.StorageProcessDao;
import com.newgen.model.StorageProcess;
import com.newgen.model.StorageProcess.Status;
import com.newgen.repository.StorageProcessRepository;
import com.newgen.wrapper.service.WrapperMongoService;

@Repository
public class StorageProcessDaoImpl implements StorageProcessDao {
	private static final Logger logger = LoggerFactory.getLogger(StorageProcessDaoImpl.class);
	@SuppressWarnings("rawtypes")
	@Autowired
	WrapperMongoService mongoTemplate;

	@Autowired
	StorageProcessRepository storageProcessRepository;

	@Override
	public StorageProcess insert(StorageProcess storageProcess) {
		return storageProcessRepository.insert(storageProcess);
	}

	@Override
	public StorageProcess findById(String id) {
		return storageProcessRepository.findOne(id);
	}

	@Override
	public StorageProcess updateStatus(String id, Status status, String storageLocationId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));

		Update update = new Update();
		update.set("status", status);
		update.set("statusChangeDateTime", new Date());
		if (storageLocationId != null && !storageLocationId.isEmpty()) {
			DBRef storageLocationRef = new DBRef("storageLocation", storageLocationId);
			update.set("storageLocation", storageLocationRef);
		}

		// FindAndModifyOptions().returnNew(true) = newly updated document
		// FindAndModifyOptions().returnNew(false) = old document (not updated
		// yet)
		@SuppressWarnings("unchecked")
		StorageProcess storageProcess = (StorageProcess) mongoTemplate.findAndModify(query, update,
				new FindAndModifyOptions().returnNew(true), StorageProcess.class);
		logger.debug("Updated Storage Process - " + storageProcess);
		return storageProcess;
	}

	@Override
	public StorageProcess findAndRemoveById(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));
		@SuppressWarnings("unchecked")
		StorageProcess storageProcess = (StorageProcess) mongoTemplate.findAndRemove(query, StorageProcess.class);
		logger.debug("Deleted Storage Process : " + storageProcess);
		return storageProcess;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StorageProcess> findAllAcknowldegedAndFailed() {
		Query query = new Query();
		Date compareDate = DateUtils.addMinutes(new Date(), -5);
		query.addCriteria((Criteria.where("status").is(Status.ACKNOWLEDGED)
				.orOperator(Criteria.where("status").is(Status.FAILED)))
						.andOperator(Criteria.where("statusChangeDateTime").lte(compareDate)));
		return mongoTemplate.find(query, StorageProcess.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StorageProcess> findAllCompletedForDays(int days) {
		Query query = new Query();
		Date compareDate = DateUtils.addDays(new Date(), -days);
		query.addCriteria(Criteria.where("status").is(Status.COMPLETED)
				.andOperator(Criteria.where("statusChangeDateTime").lte(compareDate)));
		return mongoTemplate.find(query, StorageProcess.class);
	}
}
